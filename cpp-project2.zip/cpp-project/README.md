# Ubuntu Apps

A collection of Linux game launchers written in C++.

## Applications

| App | Description |
|-----|-------------|
| **RSCRevolution Launcher** | RuneScape Classic launcher with splash screen |
| **Tibia Launcher** | Tibia MMORPG launcher with library path setup |

## Requirements

- CMake 3.16+
- GCC/G++ with C++17 support
- SDL2 and SDL2_ttf (for RSCRevolution launcher)
- Java Runtime (for RSCRevolution game)

### Install dependencies (Ubuntu/Debian)

```bash
sudo apt install build-essential cmake libsdl2-dev libsdl2-ttf-dev default-jre
```

## Building

```bash
mkdir -p build && cd build
cmake ..
make
```

## Installing

```bash
sudo make install
```

## Creating a DEB package

```bash
cpack -G DEB
```

## License

This project is licensed under the **GNU General Public License v3.0** (GPLv3).

See [LICENSE](LICENSE) for details.

## Author

**Ahmed Osman Ata Othman**

---

*Credentials to RSCRevolution and CipSoft for their respective games.*
