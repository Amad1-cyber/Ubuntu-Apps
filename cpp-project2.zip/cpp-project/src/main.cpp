// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Ahmed Osman Ata Othman
#include <iostream>

int main() {
    std::cout << "Hello, World!" << std::endl;
    return 0;
}
