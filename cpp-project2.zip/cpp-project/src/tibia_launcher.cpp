// SPDX-License-Identifier: GPL-3.0-or-later
// tibia_launcher.cpp
// A minimal Linux C++ launcher that sets LD_LIBRARY_PATH and execs Tibia.
// Build: g++ -O2 -std=c++17 tibia_launcher.cpp -o tibia_launcher
// Usage: ./tibia_launcher [/path/to/Tibia-root]

#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <unistd.h>
#include <sys/stat.h>
#include <limits.h>
#include <errno.h>

static bool pathExists(const std::string &p) {
    struct stat st{};
    return stat(p.c_str(), &st) == 0;
}

static std::string join(const std::string &a, const std::string &b) {
    if (a.empty()) return b;
    if (a.back() == '/') return a + b;
    return a + "/" + b;
}

static std::string getEnv(const char *name) {
    const char *v = getenv(name);
    return v ? std::string(v) : std::string();
}

int main(int argc, char **argv) {
    // Default Tibia root (adjust if you keep it elsewhere)
    std::string tibiaRoot = getEnv("TIBIA_ROOT");
    if (tibiaRoot.empty()) {
        tibiaRoot = std::string(getenv("HOME") ? getenv("HOME") : "") + "/Downloads/Tibia";
    }
    if (argc >= 2) {
        tibiaRoot = argv[1];
    }

    // Expected local library dirs
    const std::string libxmlLocal = join(tibiaRoot, "libxml2-build");
    const std::string libLocal    = join(tibiaRoot, "lib");

    // Tibia client path (CipSoft launcher extracts here)
    const std::string clientBin   = join(getEnv("HOME"), ".local/share/CipSoft GmbH/Tibia/packages/Tibia/bin/client");
    const std::string clientLib   = join(getEnv("HOME"), ".local/share/CipSoft GmbH/Tibia/packages/Tibia/bin/lib");

    // Basic checks
    if (!pathExists(tibiaRoot)) {
        std::cerr << "Error: Tibia root not found: " << tibiaRoot << "\n";
        return 1;
    }
    if (!pathExists(clientBin)) {
        std::cerr << "Error: Tibia client not found: " << clientBin << "\n"
                  << "Hint: run the Tibia launcher once to download packages.\n";
        return 1;
    }

    // Compose LD_LIBRARY_PATH:
    // - local libxml2-build (your compiled libxml2.so.2 exposing LIBXML2_2.4.30)
    // - local lib (any extra libs you bundle)
    // - client's own lib dir (Qt6WebEngineCore and friends)
    // - existing LD_LIBRARY_PATH (preserve user context)
    std::string existing = getEnv("LD_LIBRARY_PATH");
    std::string ldpath   = libxmlLocal + ":" + libLocal + ":" + clientLib;
    if (!existing.empty()) ldpath += ":" + existing;

    // Export environment
    if (setenv("LD_LIBRARY_PATH", ldpath.c_str(), 1) != 0) {
        std::cerr << "Error: setenv(LD_LIBRARY_PATH) failed: " << strerror(errno) << "\n";
        return 1;
    }

    // Optional: ensure working directory is Tibia root (helps relative paths)
    if (chdir(tibiaRoot.c_str()) != 0) {
        std::cerr << "Warning: chdir(" << tibiaRoot << ") failed: " << strerror(errno) << "\n";
    }

    // Build argv for execve
    std::vector<char*> args;
    args.push_back(const_cast<char*>(clientBin.c_str()));
    // Forward any extra args to Tibia client
    for (int i = 2; i < argc; ++i) {
        args.push_back(argv[i]);
    }
    args.push_back(nullptr);

    // Build environment vector (inherit current env)
    // We only need LD_LIBRARY_PATH set; execve will read process env.
    extern char **environ;
    // Exec Tibia client
    if (execve(clientBin.c_str(), args.data(), environ) == -1) {
        std::cerr << "Error: execve failed: " << strerror(errno) << "\n";
        return 1;
    }

    return 0; // unreachable if execve succeeds
}
