#!/bin/bash
# SPDX-License-Identifier: GPL-3.0-or-later
# Install script for Ubuntu Apps
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

echo "=== Ubuntu Apps Installer ==="
echo ""

# Build
echo "[1/3] Building..."
mkdir -p "$SCRIPT_DIR/build"
cd "$SCRIPT_DIR/build"
cmake ..
make -j$(nproc)

# Install to user directory
echo "[2/3] Installing to ~/.local/bin..."
mkdir -p ~/.local/bin ~/.local/share/applications

cp -v tibia_launcher ~/.local/bin/ 2>/dev/null || true
[ -f rscrevolution_launcher ] && cp -v rscrevolution_launcher ~/.local/bin/

cp -v "$SCRIPT_DIR/data/"*.desktop ~/.local/share/applications/ 2>/dev/null || true

# Update desktop database
echo "[3/3] Updating desktop database..."
if command -v update-desktop-database &>/dev/null; then
    update-desktop-database ~/.local/share/applications
fi

echo ""
echo "Installation complete!"
echo "Make sure ~/.local/bin is in your PATH."
echo ""
echo "You can now find the apps in your application menu."
