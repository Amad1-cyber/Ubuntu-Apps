#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <cstdlib>
#include <string>
#include <cmath>
#include <fstream>
#include <vector>
#include <unistd.h>
#include <utility>

// Find Tibia installation - returns pair of (directory, executable)
std::pair<std::string, std::string> findTibia() {
    // Check for installed Tibia client first
    std::string cipSoftPath = std::string(getenv("HOME")) + "/.local/share/CipSoft GmbH/Tibia/packages/Tibia/bin";
    std::string cipSoftExec = cipSoftPath + "/client";
    if (access(cipSoftExec.c_str(), X_OK) == 0) {
        return {cipSoftPath, "client"};
    }
    
    // Check for Tibia launcher locations
    std::vector<std::string> searchPaths = {
        std::string(getenv("HOME")) + "/Downloads/tibia.x64/Tibia",
        std::string(getenv("HOME")) + "/Downloads/Tibia",
        std::string(getenv("HOME")) + "/Games/Tibia",
        std::string(getenv("HOME")) + "/tibia",
        std::string(getenv("HOME")) + "/.local/share/Tibia",
        "/opt/Tibia",
        "/opt/tibia",
        "/usr/local/games/Tibia",
        std::string(getenv("HOME")) + "/Desktop/Tibia"
    };
    
    for (const auto& path : searchPaths) {
        std::string execPath = path + "/Tibia";
        if (access(execPath.c_str(), X_OK) == 0) {
            return {path, "Tibia"};
        }
    }
    return {"", ""};
}

const int SCREEN_WIDTH = 900;
const int SCREEN_HEIGHT = 650;

// Colors
const SDL_Color BLACK = {0, 0, 0, 255};
const SDL_Color GOLD = {255, 215, 0, 255};
const SDL_Color ORANGE = {255, 140, 0, 255};
const SDL_Color GREEN = {0, 200, 0, 255};
const SDL_Color WHITE = {255, 255, 255, 255};
const SDL_Color YELLOW = {255, 255, 0, 255};
const SDL_Color DARK_BG = {15, 10, 5, 255};
const SDL_Color FIRE_RED = {255, 80, 0, 255};
const SDL_Color FIRE_YELLOW = {255, 200, 50, 255};

// Draw a stone bridge
void drawBridge(SDL_Renderer* renderer, int x, int y) {
    // Water underneath
    SDL_SetRenderDrawColor(renderer, 30, 60, 120, 255);
    SDL_Rect water = {x - 120, y + 40, 240, 60};
    SDL_RenderFillRect(renderer, &water);
    
    // Water ripples
    SDL_SetRenderDrawColor(renderer, 50, 90, 150, 255);
    for (int i = 0; i < 5; i++) {
        SDL_RenderDrawLine(renderer, x - 100 + i*40, y + 55, x - 70 + i*40, y + 55);
        SDL_RenderDrawLine(renderer, x - 90 + i*40, y + 75, x - 60 + i*40, y + 75);
    }
    
    // Bridge pillars
    SDL_SetRenderDrawColor(renderer, 80, 70, 60, 255);
    SDL_Rect pillarL = {x - 90, y + 10, 20, 80};
    SDL_Rect pillarR = {x + 70, y + 10, 20, 80};
    SDL_RenderFillRect(renderer, &pillarL);
    SDL_RenderFillRect(renderer, &pillarR);
    
    // Pillar highlights
    SDL_SetRenderDrawColor(renderer, 100, 90, 80, 255);
    SDL_Rect pillarHL = {x - 90, y + 10, 5, 80};
    SDL_Rect pillarHR = {x + 70, y + 10, 5, 80};
    SDL_RenderFillRect(renderer, &pillarHL);
    SDL_RenderFillRect(renderer, &pillarHR);
    
    // Bridge arch (stone)
    SDL_SetRenderDrawColor(renderer, 90, 80, 70, 255);
    for (int i = 0; i < 30; i++) {
        int archY = (int)(20 * sin(M_PI * i / 29.0));
        SDL_Rect stone = {x - 70 + i*5, y - archY, 6, 20 + archY};
        SDL_RenderFillRect(renderer, &stone);
    }
    
    // Bridge deck
    SDL_SetRenderDrawColor(renderer, 110, 95, 80, 255);
    SDL_Rect deck = {x - 100, y - 5, 200, 15};
    SDL_RenderFillRect(renderer, &deck);
    
    // Bridge railing
    SDL_SetRenderDrawColor(renderer, 70, 60, 50, 255);
    SDL_Rect railL = {x - 100, y - 25, 8, 25};
    SDL_Rect railR = {x + 92, y - 25, 8, 25};
    SDL_RenderFillRect(renderer, &railL);
    SDL_RenderFillRect(renderer, &railR);
    
    // Railing top bar
    SDL_Rect railTop = {x - 100, y - 28, 200, 5};
    SDL_RenderFillRect(renderer, &railTop);
    
    // Stone texture on deck
    SDL_SetRenderDrawColor(renderer, 85, 75, 65, 255);
    for (int i = 0; i < 10; i++) {
        SDL_RenderDrawLine(renderer, x - 95 + i*20, y - 3, x - 95 + i*20, y + 8);
    }
}

// Draw a fire spell effect
void drawFireSpell(SDL_Renderer* renderer, int x, int y, float time) {
    // Animated fire particles
    for (int i = 0; i < 15; i++) {
        float offset = sin(time * 3 + i * 0.5f) * 10;
        float yOffset = (sin(time * 5 + i) + 1) * 15;
        int size = 8 + (int)(sin(time * 4 + i) * 4);
        
        // Outer glow (red/orange)
        SDL_SetRenderDrawColor(renderer, 255, 60 + i*10, 0, 180);
        for (int r = size + 5; r > size; r--) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    if (dx*dx + dy*dy <= r*r) {
                        SDL_RenderDrawPoint(renderer, 
                            x + (int)offset + (i % 5 - 2) * 12 + dx, 
                            y - (int)yOffset - i * 4 + dy);
                    }
                }
            }
        }
        
        // Inner fire (yellow/white core)
        int coreSize = size / 2;
        SDL_SetRenderDrawColor(renderer, 255, 220, 100, 255);
        for (int dy = -coreSize; dy <= coreSize; dy++) {
            for (int dx = -coreSize; dx <= coreSize; dx++) {
                if (dx*dx + dy*dy <= coreSize*coreSize) {
                    SDL_RenderDrawPoint(renderer, 
                        x + (int)offset + (i % 5 - 2) * 12 + dx, 
                        y - (int)yOffset - i * 4 + dy);
                }
            }
        }
    }
    
    // Central fire ball
    for (int r = 25; r > 0; r--) {
        int red = 255;
        int green = 50 + (25 - r) * 7;
        int blue = (25 - r) * 3;
        SDL_SetRenderDrawColor(renderer, red, green > 255 ? 255 : green, blue, 255);
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                if (dx*dx + dy*dy <= r*r) {
                    SDL_RenderDrawPoint(renderer, x + dx, y + dy);
                }
            }
        }
    }
    
    // White hot center
    SDL_SetRenderDrawColor(renderer, 255, 255, 200, 255);
    for (int dy = -8; dy <= 8; dy++) {
        for (int dx = -8; dx <= 8; dx++) {
            if (dx*dx + dy*dy <= 64) {
                SDL_RenderDrawPoint(renderer, x + dx, y + dy);
            }
        }
    }
}

void renderText(SDL_Renderer* renderer, TTF_Font* font, const char* text, 
                int x, int y, SDL_Color color, bool centered = true) {
    SDL_Surface* surface = TTF_RenderText_Blended(font, text, color);
    if (!surface) return;
    
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        SDL_FreeSurface(surface);
        return;
    }
    
    SDL_Rect dstRect;
    dstRect.w = surface->w;
    dstRect.h = surface->h;
    dstRect.x = centered ? x - surface->w / 2 : x;
    dstRect.y = y;
    
    SDL_RenderCopy(renderer, texture, nullptr, &dstRect);
    
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(surface);
}

int main(int argc, char* argv[]) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        SDL_Log("SDL init failed: %s", SDL_GetError());
        return 1;
    }
    
    if (TTF_Init() < 0) {
        SDL_Log("TTF init failed: %s", TTF_GetError());
        SDL_Quit();
        return 1;
    }
    
    SDL_Window* window = SDL_CreateWindow(
        "Tibia Game Launcher",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        SCREEN_WIDTH, SCREEN_HEIGHT,
        SDL_WINDOW_SHOWN
    );
    
    if (!window) {
        SDL_Log("Window creation failed: %s", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return 1;
    }
    
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }
    
    // Load fonts
    TTF_Font* fontLarge = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 36);
    TTF_Font* fontMedium = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22);
    TTF_Font* fontSmall = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18);
    
    if (!fontLarge) {
        fontLarge = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 36);
        fontMedium = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 22);
        fontSmall = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 18);
    }
    
    if (!fontLarge || !fontMedium || !fontSmall) {
        SDL_Log("Failed to load fonts");
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }
    
    bool running = true;
    bool launchGame = false;
    SDL_Event event;
    Uint32 startTime = SDL_GetTicks();
    
    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            } else if (event.type == SDL_KEYDOWN || event.type == SDL_MOUSEBUTTONDOWN) {
                launchGame = true;
                running = false;
            }
        }
        
        float time = (SDL_GetTicks() - startTime) / 1000.0f;
        int pulse = (int)(200 + 55 * sin(time * 2));
        
        // Clear with dark background
        SDL_SetRenderDrawColor(renderer, DARK_BG.r, DARK_BG.g, DARK_BG.b, 255);
        SDL_RenderClear(renderer);
        
        // Decorative borders
        SDL_SetRenderDrawColor(renderer, GOLD.r, GOLD.g, GOLD.b, 255);
        SDL_Rect border1 = {8, 8, SCREEN_WIDTH - 16, SCREEN_HEIGHT - 16};
        SDL_RenderDrawRect(renderer, &border1);
        SDL_SetRenderDrawColor(renderer, ORANGE.r, ORANGE.g, ORANGE.b, 255);
        SDL_Rect border2 = {12, 12, SCREEN_WIDTH - 24, SCREEN_HEIGHT - 24};
        SDL_RenderDrawRect(renderer, &border2);
        SDL_SetRenderDrawColor(renderer, GOLD.r, GOLD.g, GOLD.b, 255);
        SDL_Rect border3 = {16, 16, SCREEN_WIDTH - 32, SCREEN_HEIGHT - 32};
        SDL_RenderDrawRect(renderer, &border3);
        
        // Draw bridge on left side
        drawBridge(renderer, 200, 180);
        
        // Draw fire spell on right side (animated)
        drawFireSpell(renderer, 700, 180, time);
        
        // Title - "TIBIA" in gold
        renderText(renderer, fontLarge, "T I B I A", SCREEN_WIDTH / 2, 320, GOLD);
        
        // "Game Launcher for Linux" in orange
        renderText(renderer, fontMedium, "Game Launcher for Linux", SCREEN_WIDTH / 2, 365, ORANGE);
        
        // Creator credit in green
        renderText(renderer, fontMedium, "Created by: Ahmed Osman Ata Othman", SCREEN_WIDTH / 2, 420, GREEN);
        
        // Thanks message in yellow
        renderText(renderer, fontSmall, "Thanks to Tibia game creators", SCREEN_WIDTH / 2, 470, YELLOW);
        
        // Blessings in white
        renderText(renderer, fontSmall, "Blessings to all.", SCREEN_WIDTH / 2, 500, WHITE);
        
        // Pulsing launch text
        SDL_Color pulseColor = {(Uint8)pulse, (Uint8)(pulse * 0.7), 0, 255};
        renderText(renderer, fontMedium, "[ Click or Press Any Key to Launch ]", 
                   SCREEN_WIDTH / 2, 570, pulseColor);
        
        SDL_RenderPresent(renderer);
        SDL_Delay(16);
    }
    
    TTF_CloseFont(fontLarge);
    TTF_CloseFont(fontMedium);
    TTF_CloseFont(fontSmall);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    TTF_Quit();
    SDL_Quit();
    
    if (launchGame) {
        auto [tibiaPath, tibiaExec] = findTibia();
        if (!tibiaPath.empty()) {
            std::string home = getenv("HOME");
            std::string compatLib = home + "/.local/lib/tibia-compat/usr/lib/x86_64-linux-gnu";
            std::string cmd = "cd '" + tibiaPath + "' && "
                              "LD_LIBRARY_PATH=" + compatLib + ":./lib:$LD_LIBRARY_PATH "
                              "./" + tibiaExec + " &";
            system(cmd.c_str());
        } else {
            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Tibia Not Found",
                "Could not find Tibia installation.\n"
                "Please install Tibia in one of these locations:\n"
                "- ~/Downloads/tibia.x64/Tibia\n"
                "- ~/Games/Tibia\n"
                "- /opt/Tibia", nullptr);
        }
    }
    
    return 0;
}
