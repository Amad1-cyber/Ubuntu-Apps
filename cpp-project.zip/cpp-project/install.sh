#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BINARY="$SCRIPT_DIR/build/tibia_launcher"
DESKTOP="$SCRIPT_DIR/tibia-launcher.desktop"

# Build if not exists
if [ ! -f "$BINARY" ]; then
    echo "Building tibia_launcher..."
    mkdir -p "$SCRIPT_DIR/build"
    g++ -O2 -std=c++17 "$SCRIPT_DIR/src/tibia_launcher.cpp" -o "$BINARY"
fi

# Install binary
echo "Installing binary to ~/.local/bin/"
mkdir -p ~/.local/bin
cp "$BINARY" ~/.local/bin/tibia_launcher
chmod +x ~/.local/bin/tibia_launcher

# Install desktop entry
echo "Installing desktop entry..."
mkdir -p ~/.local/share/applications
cp "$DESKTOP" ~/.local/share/applications/tibia-launcher.desktop

# Update desktop database
if command -v update-desktop-database &> /dev/null; then
    update-desktop-database ~/.local/share/applications
fi

echo ""
echo "Installation complete!"
echo "Make sure ~/.local/bin is in your PATH."
echo "You can now launch 'Tibia Launcher' from your application menu."
