# cpp-project

A C++ project using CMake.

## Building

```bash
cd build
cmake ..
make
```

## Running

```bash
./build/cpp-project
```
