#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <cstdlib>
#include <string>
#include <cmath>

// Window dimensions
const int SCREEN_WIDTH = 800;
const int SCREEN_HEIGHT = 600;

// Colors
const SDL_Color BLACK = {0, 0, 0, 255};
const SDL_Color GOLD = {255, 215, 0, 255};
const SDL_Color SILVER = {192, 192, 192, 255};
const SDL_Color GREEN = {0, 200, 0, 255};
const SDL_Color MITHRIL_BLUE = {70, 130, 180, 255};
const SDL_Color MITHRIL_LIGHT = {135, 180, 220, 255};
const SDL_Color MITHRIL_DARK = {40, 80, 120, 255};
const SDL_Color BG_COLOR = {20, 20, 30, 255};

// Draw a mithril sword (programmatically generated)
void drawMithrilSword(SDL_Renderer* renderer, int centerX, int centerY) {
    // Sword blade (main body)
    SDL_SetRenderDrawColor(renderer, MITHRIL_BLUE.r, MITHRIL_BLUE.g, MITHRIL_BLUE.b, 255);
    
    // Blade vertices (elongated diamond shape)
    const int bladeLength = 180;
    const int bladeWidth = 20;
    
    // Draw blade with gradient effect
    for (int i = 0; i < bladeWidth; i++) {
        int shade = (i < bladeWidth/2) ? i * 4 : (bladeWidth - i) * 4;
        SDL_SetRenderDrawColor(renderer, 
            MITHRIL_BLUE.r + shade > 255 ? 255 : MITHRIL_BLUE.r + shade,
            MITHRIL_BLUE.g + shade > 255 ? 255 : MITHRIL_BLUE.g + shade,
            MITHRIL_BLUE.b + shade > 255 ? 255 : MITHRIL_BLUE.b + shade, 255);
        
        int offset = bladeWidth/2 - i;
        SDL_RenderDrawLine(renderer, 
            centerX + offset, centerY - bladeLength/2,
            centerX + offset, centerY + bladeLength/3);
    }
    
    // Blade tip (pointed)
    for (int y = 0; y < 60; y++) {
        int width = (60 - y) * bladeWidth / 60 / 2;
        SDL_SetRenderDrawColor(renderer, MITHRIL_LIGHT.r, MITHRIL_LIGHT.g, MITHRIL_LIGHT.b, 255);
        SDL_RenderDrawLine(renderer, 
            centerX - width, centerY - bladeLength/2 - y,
            centerX + width, centerY - bladeLength/2 - y);
    }
    
    // Blade edge highlights
    SDL_SetRenderDrawColor(renderer, MITHRIL_LIGHT.r, MITHRIL_LIGHT.g, MITHRIL_LIGHT.b, 255);
    SDL_RenderDrawLine(renderer, centerX - bladeWidth/2, centerY - bladeLength/2,
                       centerX, centerY - bladeLength/2 - 60);
    SDL_RenderDrawLine(renderer, centerX + bladeWidth/2, centerY - bladeLength/2,
                       centerX, centerY - bladeLength/2 - 60);
    
    // Fuller (groove in blade)
    SDL_SetRenderDrawColor(renderer, MITHRIL_DARK.r, MITHRIL_DARK.g, MITHRIL_DARK.b, 255);
    SDL_RenderDrawLine(renderer, centerX, centerY - bladeLength/2 + 10,
                       centerX, centerY + bladeLength/4);
    SDL_RenderDrawLine(renderer, centerX + 1, centerY - bladeLength/2 + 10,
                       centerX + 1, centerY + bladeLength/4);
    
    // Cross guard (hilt)
    SDL_SetRenderDrawColor(renderer, GOLD.r, GOLD.g, GOLD.b, 255);
    SDL_Rect crossGuard = {centerX - 40, centerY + bladeLength/3, 80, 12};
    SDL_RenderFillRect(renderer, &crossGuard);
    
    // Guard decorations
    SDL_SetRenderDrawColor(renderer, SILVER.r, SILVER.g, SILVER.b, 255);
    SDL_Rect guardLeft = {centerX - 45, centerY + bladeLength/3 - 3, 10, 18};
    SDL_Rect guardRight = {centerX + 35, centerY + bladeLength/3 - 3, 10, 18};
    SDL_RenderFillRect(renderer, &guardLeft);
    SDL_RenderFillRect(renderer, &guardRight);
    
    // Handle/grip
    SDL_SetRenderDrawColor(renderer, 60, 40, 20, 255); // Brown leather
    SDL_Rect handle = {centerX - 8, centerY + bladeLength/3 + 12, 16, 50};
    SDL_RenderFillRect(renderer, &handle);
    
    // Handle wrapping
    SDL_SetRenderDrawColor(renderer, 80, 55, 30, 255);
    for (int i = 0; i < 5; i++) {
        SDL_Rect wrap = {centerX - 9, centerY + bladeLength/3 + 15 + i*10, 18, 4};
        SDL_RenderFillRect(renderer, &wrap);
    }
    
    // Pommel
    SDL_SetRenderDrawColor(renderer, MITHRIL_BLUE.r, MITHRIL_BLUE.g, MITHRIL_BLUE.b, 255);
    for (int r = 12; r > 0; r--) {
        int shade = (12 - r) * 5;
        SDL_SetRenderDrawColor(renderer,
            MITHRIL_BLUE.r + shade > 255 ? 255 : MITHRIL_BLUE.r + shade,
            MITHRIL_BLUE.g + shade > 255 ? 255 : MITHRIL_BLUE.g + shade,
            MITHRIL_BLUE.b + shade > 255 ? 255 : MITHRIL_BLUE.b + shade, 255);
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                if (dx*dx + dy*dy <= r*r) {
                    SDL_RenderDrawPoint(renderer, 
                        centerX + dx, 
                        centerY + bladeLength/3 + 70 + dy);
                }
            }
        }
    }
}

void renderText(SDL_Renderer* renderer, TTF_Font* font, const char* text, 
                int x, int y, SDL_Color color, bool centered = true) {
    SDL_Surface* surface = TTF_RenderText_Blended(font, text, color);
    if (!surface) return;
    
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    if (!texture) {
        SDL_FreeSurface(surface);
        return;
    }
    
    SDL_Rect dstRect;
    dstRect.w = surface->w;
    dstRect.h = surface->h;
    dstRect.x = centered ? x - surface->w / 2 : x;
    dstRect.y = y;
    
    SDL_RenderCopy(renderer, texture, nullptr, &dstRect);
    
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(surface);
}

int main(int argc, char* argv[]) {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        SDL_Log("SDL initialization failed: %s", SDL_GetError());
        return 1;
    }
    
    // Initialize SDL_ttf
    if (TTF_Init() < 0) {
        SDL_Log("TTF initialization failed: %s", TTF_GetError());
        SDL_Quit();
        return 1;
    }
    
    // Create window
    SDL_Window* window = SDL_CreateWindow(
        "RuneScape Classic Linux Launcher",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        SCREEN_WIDTH, SCREEN_HEIGHT,
        SDL_WINDOW_SHOWN
    );
    
    if (!window) {
        SDL_Log("Window creation failed: %s", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return 1;
    }
    
    // Create renderer
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        SDL_Log("Renderer creation failed: %s", SDL_GetError());
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }
    
    // Load fonts (try common system fonts)
    TTF_Font* fontLarge = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 32);
    TTF_Font* fontMedium = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24);
    TTF_Font* fontSmall = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 18);
    
    // Fallback fonts if DejaVu not available
    if (!fontLarge) {
        fontLarge = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 32);
        fontMedium = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 24);
        fontSmall = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 18);
    }
    
    if (!fontLarge || !fontMedium || !fontSmall) {
        SDL_Log("Failed to load fonts. Please install fonts-dejavu or fonts-liberation.");
        SDL_DestroyRenderer(renderer);
        SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
        return 1;
    }
    
    bool running = true;
    bool launchGame = false;
    SDL_Event event;
    
    Uint32 startTime = SDL_GetTicks();
    
    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = false;
            } else if (event.type == SDL_KEYDOWN || event.type == SDL_MOUSEBUTTONDOWN) {
                launchGame = true;
                running = false;
            }
        }
        
        // Calculate animation time
        float time = (SDL_GetTicks() - startTime) / 1000.0f;
        int pulse = (int)(128 + 127 * sin(time * 2));
        
        // Clear screen
        SDL_SetRenderDrawColor(renderer, BG_COLOR.r, BG_COLOR.g, BG_COLOR.b, 255);
        SDL_RenderClear(renderer);
        
        // Draw decorative border
        SDL_SetRenderDrawColor(renderer, GOLD.r, GOLD.g, GOLD.b, 255);
        SDL_Rect border1 = {10, 10, SCREEN_WIDTH - 20, SCREEN_HEIGHT - 20};
        SDL_RenderDrawRect(renderer, &border1);
        SDL_SetRenderDrawColor(renderer, SILVER.r, SILVER.g, SILVER.b, 255);
        SDL_Rect border2 = {15, 15, SCREEN_WIDTH - 30, SCREEN_HEIGHT - 30};
        SDL_RenderDrawRect(renderer, &border2);
        
        // Draw mithril sword (centered, upper portion)
        drawMithrilSword(renderer, SCREEN_WIDTH / 2, 200);
        
        // Title text - RuneScape Classic (Gold)
        renderText(renderer, fontLarge, "RuneScape Classic", 
                   SCREEN_WIDTH / 2, 360, GOLD);
        
        // Linux Launcher (Silver)
        renderText(renderer, fontLarge, "Linux Launcher", 
                   SCREEN_WIDTH / 2, 395, SILVER);
        
        // Created by line (Black with green background simulation - using green)
        renderText(renderer, fontMedium, "Created by Ahmed Osman Ata Othman", 
                   SCREEN_WIDTH / 2, 445, GREEN);
        
        // Credits line (Green)
        renderText(renderer, fontSmall, "Credentials to RSCRevolution for the connection", 
                   SCREEN_WIDTH / 2, 480, GREEN);
        
        // Pulsing "Click to Launch" text
        SDL_Color pulseColor = {(Uint8)pulse, (Uint8)(pulse * 0.84), 0, 255};
        renderText(renderer, fontMedium, "[ Click or Press Any Key to Launch ]", 
                   SCREEN_WIDTH / 2, 540, pulseColor);
        
        SDL_RenderPresent(renderer);
        SDL_Delay(16); // ~60 FPS
    }
    
    // Cleanup
    TTF_CloseFont(fontLarge);
    TTF_CloseFont(fontMedium);
    TTF_CloseFont(fontSmall);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    TTF_Quit();
    SDL_Quit();
    
    // Launch the game if requested
    if (launchGame) {
        std::string command = "java -jar /home/ahmedo/Desktop/RSCRevolution.jar &";
        system(command.c_str());
    }
    
    return 0;
}
