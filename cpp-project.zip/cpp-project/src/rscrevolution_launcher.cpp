// RSCRevolution Linux Launcher
// Created by Ahmed Osman Ata Othman
// Build: g++ -O2 -std=c++17 $(pkg-config --cflags --libs sdl2 SDL2_ttf) rscrevolution_launcher.cpp -o rscrevolution_launcher

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <cmath>
#include <string>
#include <unistd.h>

static const char* JAR_PATH = "/home/ahmedo/Desktop/RSCRevolution.jar";
static const int WIDTH = 600;
static const int HEIGHT = 450;

// Colors
static const SDL_Color COLOR_BLACK = {0, 0, 0, 255};
static const SDL_Color COLOR_GOLD = {217, 165, 33, 255};
static const SDL_Color COLOR_SILVER = {192, 192, 204, 255};
static const SDL_Color COLOR_GREEN = {0, 204, 51, 255};
static const SDL_Color COLOR_MITHRIL_LIGHT = {102, 178, 230, 255};
static const SDL_Color COLOR_MITHRIL_DARK = {26, 77, 153, 255};
static const SDL_Color COLOR_BROWN = {102, 51, 26, 255};
static const SDL_Color COLOR_GRAY = {128, 128, 128, 255};

void drawSword(SDL_Renderer* renderer, int cx, int cy) {
    // Blade (mithril blue)
    SDL_SetRenderDrawColor(renderer, 51, 128, 204, 255);
    const SDL_Point blade[] = {
        {cx, cy - 150},      // Tip
        {cx + 18, cy - 105}, // Right top
        {cx + 12, cy + 30},  // Right bottom
        {cx, cy + 45},       // Center bottom
        {cx - 12, cy + 30},  // Left bottom
        {cx - 18, cy - 105}, // Left top
        {cx, cy - 150}       // Back to tip
    };
    for (int i = 0; i < 6; i++) {
        SDL_RenderDrawLine(renderer, blade[i].x, blade[i].y, blade[i+1].x, blade[i+1].y);
    }
    // Fill blade with lines
    for (int y = cy - 145; y < cy + 40; y++) {
        int progress = (y - (cy - 145)) / (float)(185);
        int width = 12 + (y > cy ? (cy + 45 - y) / 3 : 0);
        if (y < cy - 100) width = (y - (cy - 150)) / 3;
        SDL_SetRenderDrawColor(renderer, 51 + progress * 20, 128 - progress * 30, 204 - progress * 50, 255);
        SDL_RenderDrawLine(renderer, cx - width, y, cx + width, y);
    }
    
    // Blade highlight
    SDL_SetRenderDrawColor(renderer, 180, 220, 255, 200);
    SDL_RenderDrawLine(renderer, cx, cy - 140, cx, cy + 30);
    
    // Guard (gold)
    SDL_SetRenderDrawColor(renderer, 217, 165, 33, 255);
    SDL_Rect guard = {cx - 45, cy + 38, 90, 18};
    SDL_RenderFillRect(renderer, &guard);
    SDL_SetRenderDrawColor(renderer, 153, 102, 0, 255);
    SDL_RenderDrawRect(renderer, &guard);
    
    // Handle (brown)
    SDL_SetRenderDrawColor(renderer, 102, 51, 26, 255);
    SDL_Rect handle = {cx - 9, cy + 56, 18, 68};
    SDL_RenderFillRect(renderer, &handle);
    
    // Handle wrapping
    SDL_SetRenderDrawColor(renderer, 77, 38, 13, 255);
    for (int i = 0; i < 5; i++) {
        SDL_Rect wrap = {cx - 9, cy + 60 + i * 14, 18, 5};
        SDL_RenderFillRect(renderer, &wrap);
    }
    
    // Pommel (silver)
    SDL_SetRenderDrawColor(renderer, 192, 192, 204, 255);
    for (int r = 15; r > 0; r--) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int)sqrt(r*r - dy*dy);
            SDL_RenderDrawLine(renderer, cx - dx, cy + 132 + dy, cx + dx, cy + 132 + dy);
        }
    }
}

void renderText(SDL_Renderer* renderer, TTF_Font* font, const char* text, int x, int y, SDL_Color color, bool centered = true) {
    SDL_Surface* surface = TTF_RenderText_Blended(font, text, color);
    if (!surface) return;
    SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_Rect dst = {x, y, surface->w, surface->h};
    if (centered) dst.x = x - surface->w / 2;
    SDL_RenderCopy(renderer, texture, nullptr, &dst);
    SDL_DestroyTexture(texture);
    SDL_FreeSurface(surface);
}

int main(int argc, char* argv[]) {
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();
    
    SDL_Window* window = SDL_CreateWindow(
        "RSCRevolution Launcher",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        WIDTH, HEIGHT, SDL_WINDOW_SHOWN
    );
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    
    // Load fonts
    TTF_Font* fontLarge = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 28);
    TTF_Font* fontMedium = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 16);
    TTF_Font* fontSmall = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14);
    
    if (!fontLarge || !fontMedium || !fontSmall) {
        // Fallback fonts
        fontLarge = TTF_OpenFont("/usr/share/fonts/truetype/freefont/FreeSansBold.ttf", 28);
        fontMedium = TTF_OpenFont("/usr/share/fonts/truetype/freefont/FreeSansBold.ttf", 16);
        fontSmall = TTF_OpenFont("/usr/share/fonts/truetype/freefont/FreeSans.ttf", 14);
    }
    
    bool running = true;
    bool launchGame = false;
    SDL_Event event;
    
    while (running) {
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) running = false;
            if (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE) running = false;
            if (event.type == SDL_MOUSEBUTTONDOWN) {
                launchGame = true;
                running = false;
            }
        }
        
        // Dark background gradient (approximate with solid)
        SDL_SetRenderDrawColor(renderer, 15, 15, 25, 255);
        SDL_RenderClear(renderer);
        
        // Draw sword
        drawSword(renderer, WIDTH / 2, HEIGHT / 2 - 40);
        
        // Title with gold outline effect
        if (fontLarge) {
            // Gold outline
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    if (dx || dy)
                        renderText(renderer, fontLarge, "RuneScape Classic Linux Launcher", WIDTH/2 + dx, 40 + dy, COLOR_GOLD);
                }
            }
            // Green text
            renderText(renderer, fontLarge, "RuneScape Classic Linux Launcher", WIDTH/2, 40, COLOR_GREEN);
        }
        
        // Author (silver)
        if (fontMedium) {
            renderText(renderer, fontMedium, "Created by Ahmed Osman Ata Othman", WIDTH/2, HEIGHT - 80, COLOR_SILVER);
        }
        
        // Credits (gold)
        if (fontSmall) {
            renderText(renderer, fontSmall, "Credentials to RSCRevolution for the connection", WIDTH/2, HEIGHT - 50, COLOR_GOLD);
            renderText(renderer, fontSmall, "Click anywhere to launch game...", WIDTH/2, HEIGHT - 20, COLOR_GRAY);
        }
        
        SDL_RenderPresent(renderer);
        SDL_Delay(16);
    }
    
    if (fontLarge) TTF_CloseFont(fontLarge);
    if (fontMedium) TTF_CloseFont(fontMedium);
    if (fontSmall) TTF_CloseFont(fontSmall);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    TTF_Quit();
    SDL_Quit();
    
    if (launchGame) {
        execlp("java", "java", "-jar", JAR_PATH, nullptr);
    }
    
    return 0;
}
